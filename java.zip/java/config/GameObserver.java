package config;

public interface GameObserver {
    void onLevelChange();
}
